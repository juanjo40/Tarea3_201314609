package sandr;

import java.util.Scanner;

public class sandr {

	 public static void main(String[]args){
		
		 int n;
		 int r;
		
		 
		 Scanner  S = new Scanner(System.in);
		 
		 System.out.println("ingresar numero");
		 n = S.nextInt();
		 
		 r = n % 2;
		 if(r == 0){
			 System.out.println("es par");
		 }
		 else{
			 System.out.println("es impar");
		 }
		 
	 } 
	
}
